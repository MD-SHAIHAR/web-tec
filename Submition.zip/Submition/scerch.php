<html>
<head>
	<title>search</title>
	<style>
		table, th, td {
		  border: 1px solid black;
		  border-collapse: collapse;
		}
		th, td {
		  padding: 10px;
		}
	</style>
</head>
<body>
	<h1>Search</h1>
	<form action="/search" method="get">
  <input type="text" placeholder="Search..." name="q">
  <button type="submit">Search</button>
</form>

	<table>
  <tr>
    <th>Name</th>
    <th>Profit</th>
    <th></th>
    <th></th>
  </tr>
  <tr>
    <td>Samsung</td>
    <td> 5500</td>
    <td><a href="editproduct.php" class="button">edit</a></td>
    <td><a href="deleteproduct.php" class="button">delete</a></td>
  </tr>
  <tr>
    <td>Nokia</td>
    <td> 1500</td>
    <td><a href="editproduct.php" class="button">edit</a></td>
    <td><a href="deleteproduct.php" class="button">delete</a></td>
  </tr>
  <tr>
   <td>Xioami</td>
    <td> 3000</td>
    <td><a href="editproduct.php" class="button">edit</a></td>
    <td><a href="deleteproduct.php" class="button">delete</a></td>
  </tr>
</table>

</body>
</html>