<!DOCTYPE html>
<html>
<head>
	<title>add product</title>
</head>
<body>
	
	<h2>Add Product</h2>
	<form method="post" action="">
		<label for="name">Name:</label>
		<input type="text" id="name" name="name" ><br><br>
		<label for="buying_price">Buying Price:</label>
		<input type="number" id="buying_price" name="buying price"><br><br>
		<label for="selling_price">Selling Price:</label>
		<input type="number" id="selling_price" name="selling_price" ><br><br>
		<label for="display_status">Display:</label>
		<input type="checkbox" id="display_status" name="display_status" value="yes" ><br><br>
		<input type="submit" value="Save">
	</form>

	
	</table>
</body>
</html>
